echo on
fg seismo
write raw.sac
rtrend verbose
write rtrend_sac.sac
quit
