echo on
fg seismo
write raw.sac
cut 10 15
read raw.sac
write cut_sac.sac
quit
