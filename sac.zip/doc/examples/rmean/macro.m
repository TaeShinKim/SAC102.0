echo on
fg seismo
add (pi/2)
write raw.sac
rmean
write rmean_sac.sac
quit
