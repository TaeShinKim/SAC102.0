#!/bin/sh

sac <<EOF
fg seismo
lh columns 2
quit
EOF

