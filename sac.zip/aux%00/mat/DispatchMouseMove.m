function DispatchMouseMove
% Currently no asociated action